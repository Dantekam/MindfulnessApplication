[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/u2GKD8cn)

This app was developed primarily for Android devices and testing was done on a Moto G*Power phone
The dimensions of this product are 1080x2300.